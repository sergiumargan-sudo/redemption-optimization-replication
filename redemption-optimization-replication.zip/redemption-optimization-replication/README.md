# Redemption Optimization — Replication Pack

This repository contains simple, reproducible simulations that illustrate the *Margan Optimization Paradox (MOP)*:
> Evil is necessary **once** to ground redemption goods (mercy, justice), but any **repetition** adds **no value** and only increases costs.

## Structure
- `scripts/sim_typal.py` — Typal credits (full credit after the first rejection), linear costs.
- `scripts/sim_concave.py` — Concave credits (sqrt), linear costs.
- `configs/weights.yaml` — Example weights (α, β, γ, κ, μ, ν).
- `artifacts/` — Figures produced by scripts.
- `data/` — (Optional) place synthetic event streams here.

## Usage
Create a Python 3 environment with NumPy and Matplotlib installed, then:

```bash
python scripts/sim_typal.py
python scripts/sim_concave.py
```

Figures will be saved to `artifacts/`.

## Claim (Tested)
Under typal/concave credits and positive per-rejection cost κ>0:
- Objective J peaks at **one** realized rejection (R=1),
- declines for R>1, confirming *minimal-trigger optimality*.

## License
- Code: MIT (see `LICENSE-CODE`).
- Text (this README, papers, PDFs): CC BY-NC-ND 4.0 (see `LICENSE-TEXT`).

Generated on 2025-09-08.
