import numpy as np
import matplotlib.pyplot as plt

R = np.arange(0, 11)               # number of rejections
credits = np.where(R >= 1, 10, 0)  # typal: full credit once R>=1
costs = 5 * R
J = credits - costs

print("Rejections:", R)
print("J:", J)

plt.figure()
plt.plot(R, J, marker='o')
plt.axvline(1, linestyle='--')
plt.title("Objective J vs. Rejections (Typal Credits)")
plt.xlabel("Number of Rejections (R)")
plt.ylabel("Objective J")
plt.grid(True)
plt.tight_layout()
plt.savefig("artifacts/J_vs_R_typal.png")
