import numpy as np
import matplotlib.pyplot as plt

R = np.arange(0, 11)                # number of rejections
credits = 10 * np.sqrt(R)           # concave returns
costs = 5 * R
J = credits - costs

print("Rejections:", R)
print("J:", J.round(2))

plt.figure()
plt.plot(R, J, marker='o')
plt.axvline(1, linestyle='--')
plt.title("Objective J vs. Rejections (Concave Credits)")
plt.xlabel("Number of Rejections (R)")
plt.ylabel("Objective J")
plt.grid(True)
plt.tight_layout()
plt.savefig("artifacts/J_vs_R_concave.png")
